from setuptools import setup

setup(name='sse-distributions-42',
      version='0.2',
      description='Gaussian distributions',
      packages=['distributions'],
      zip_safe=False)
